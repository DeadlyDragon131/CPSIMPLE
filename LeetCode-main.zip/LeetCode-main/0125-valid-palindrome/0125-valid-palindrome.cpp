class Solution {
public:
    bool isalnum(char c){
         if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >='0' && c <='9')){
            return true;
         }
         return false;
    }
    bool isPalindrome(string s) {
         int n = s.length();
         int i = 0;
         int j = n-1;
         while(i < j){
            while(i < j && !isalnum(s[i])){
                i++;
            }
            while(i < j && !isalnum(s[j])){
                j--;
            }
            if((char)tolower(s[i]) != (char)tolower(s[j])){
                return false;
            }
            i++;
            j--;
         }
         return true;
    }
};