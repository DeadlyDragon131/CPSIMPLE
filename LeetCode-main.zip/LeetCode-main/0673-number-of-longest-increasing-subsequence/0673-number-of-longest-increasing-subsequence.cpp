class Solution
{
    public:
        int findNumberOfLIS(vector<int> &nums)
        {
            int n = nums.size();
            vector<pair<int, int>> dp(n);
            int LISLen = 0, res = 0;

            for (int i = n - 1; i >= 0; i--)
            {
                int maxlen = 1, maxcnt = 1;
                for (int j = i + 1; j < n; j++)
                {
                    int len = dp[j].first;
                    int cnt = dp[j].second;
                    if (nums[j] > nums[i])
                    {
                        if (len + 1 > maxlen)
                        {
                            maxlen = len + 1;
                            maxcnt = cnt;
                        }
                        else if (len + 1 == maxlen)
                        {
                            maxcnt += cnt;
                        }
                    }
                }
                (dp[i]).first = maxlen;
                (dp[i]).second = maxcnt;
                if (maxlen > LISLen)
                {
                    LISLen = maxlen;
                    res = maxcnt;
                }
                else if (maxlen == LISLen)
                {
                    res += maxcnt;
                }
            }
            return res;
        }
};