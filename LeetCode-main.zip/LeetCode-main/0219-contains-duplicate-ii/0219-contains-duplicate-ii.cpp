class Solution {
public:
    bool containsNearbyDuplicate(vector<int>& nums, int k) {
        unordered_map<int,int> um;
         int l = 0;
         for(int r = 0;r < nums.size();r++){
            
            if(r-l < k+1){
                um[nums[r]] += 1;
            }
            else{
                um[nums[l]] = 0;
                l++; 
                um[nums[r]] += 1;
            }
            if(um[nums[r]] > 1){
                return true;
            }
         }
         return false;
    }
};