class Solution
{
    public:
        int maxNumberOfBalloons(string text)
        {
            int res = INT_MAX;
            unordered_map<char, int> m1;
            for (int i = 0; i < text.size(); i++)
            {
                m1[text[i]] = 0;
            }
            unordered_map<char, int> m2;
            for (int i = 0; i < text.size(); i++)
            {
                m1[text[i]] += 1;
            }
            m2['b'] = 1;
            m2['a'] = 1;
            m2['l'] = 2;
            m2['o'] = 2;
            m2['n'] = 1;
            for (auto &x: m2)
            {
                if (m1.find(x.first) != m1.end())
                {
                    res = min(res, m1[x.first] / m2[x.first]);
                }
                else
                {
                    return 0;
                }
            }

            return res;
        }
};