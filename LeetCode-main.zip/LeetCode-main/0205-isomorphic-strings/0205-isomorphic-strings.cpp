class Solution
{
    public:
        bool isIsomorphic(string s, string t)
        {
            unordered_map<char, char> umst;
            unordered_map<char, char> umts;

            for (int i = 0; i < s.size(); i++)
            {
                if ((umst.find(s[i]) != umst.end() && umst[s[i]] != t[i]) || (umts.find(t[i]) != umts.end() && umts[t[i]] != s[i]))
                {
                    return false;
                }
                umst[s[i]] = t[i];
                umts[t[i]] = s[i];
            }
            return true;
        }
};