class Solution {
public:
    bool isSubsequence(string s, string t) {
        int start = 0;
         for(int i = 0;i < s.length();i++){
            int j;
            for(j = start;j < t.length();j++){
                if(t[j] == s[i]){
                    start = j+1;
                    break;
                }
            }
            if(j == t.length()){
                return false;
            }
         }
         return true;
    }
};