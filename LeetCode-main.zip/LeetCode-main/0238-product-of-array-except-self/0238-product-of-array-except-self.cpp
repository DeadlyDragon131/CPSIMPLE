class Solution
{
    public:
        vector<int> productExceptSelf(vector<int> &nums)
        {
            int n = nums.size();
            vector<int> myarr(n);
            int prefix = 1;
            for (int i = 0; i < n; i++)
            {
                myarr[i] = prefix;
                prefix *= nums[i];
            }
            int postfix = 1;
            for (int j = n - 1; j >= 0; j--)
            {
                myarr[j] *= postfix;
                postfix *= nums[j];
            }
            return myarr;
        }
};