class Solution {
public:
    int sumOfSquares(int n){
        int res = 0;
        while(n!=0){
            res += pow(n%10,2); 
            n/=10;
        }
        return res;
    }

    bool isHappy(int n) {
        unordered_set<int> s;
        if(n == 1){
            return true;
        }
        while(true){
            if(s.find(n) == s.end()){
            s.insert(n);
            n = sumOfSquares(n);
            }
            else{
                break;
            }
            if(n == 1){
                return true;
            }
        }
        return false;
    }
};