class Solution {
public:
    unordered_map<string,string> emap;
    unordered_map<string,string> dmap;
    // Encodes a URL to a shortened URL.
    string encode(string longUrl) {
        if(emap.find(longUrl) == emap.end()){
            emap[longUrl] = (emap.size() + 1);
            dmap[emap[longUrl]] = longUrl;
        }

        return emap[longUrl];
    }

    // Decodes a shortened URL to its original URL.
    string decode(string shortUrl) {
        return dmap[shortUrl];
    }
};

// Your Solution object will be instantiated and called as such:
// Solution solution;
// solution.decode(solution.encode(url));