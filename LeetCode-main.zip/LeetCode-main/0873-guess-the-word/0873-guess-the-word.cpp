/**
 * // This is the Master's API interface.
 * // You should not implement it, or speculate about its implementation
 * class Master {
 *   public:
 *     int guess(string word);
 * };
 */
class Solution {
public:
      int countMatches(string w1, string w2)
        {
            int cnt = 0;
            for (int i = 0; i < 6; i++)
            {
                if (w1[i] == w2[i])
                {
                    cnt++;
                }
            }
            return cnt;
        }
    void findSecretWord(vector<string> &words, Master &master)
    {
        srand(time(0));
        vector<string> candidates;
        for (int i = 0; i < words.size(); i++)
        {
            candidates.push_back(words[i]);
        }

        while (!candidates.empty()) {
                vector<string> temp;
                int randg = (rand() % candidates.size());
                string cstr = candidates[randg]; 
                int guess = master.guess(cstr);
                if(guess == 6){
                    return;
                }
            for(auto x: candidates){
                if(countMatches(cstr,x) == guess){
                   temp.push_back(x); 
                }
            }
            candidates = temp;
        }
    }
};