class Solution {
public:
    vector<int> plusOne(vector<int>& digits) {
            int one = 1,i = digits.size() - 1;
            while(one){
                if(i >= 0){
                    if(digits[i] != 9){
                       one = 0;
                       digits[i] += 1;   
                                   }               
                    else{
                        digits[i] = 0;
                        one = 1;
                    }
                }
                else{
                    digits.insert(digits.begin()+ 0,1);
                    break;
                }
                i-=1;
            }
            return digits; 
    }
};