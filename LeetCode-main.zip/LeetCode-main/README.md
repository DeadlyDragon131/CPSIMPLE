# LeetCode
A collection of LeetCode questions to ace the coding interview! - Created using [LeetHub v2](https://github.com/arunbhardwaj/LeetHub-2.0)

<!---LeetCode Topics Start-->
# LeetCode Topics
## Array
|  |
| ------- |
| [0011-container-with-most-water](https://github.com/DeadlyDragon131/LeetCode/tree/master/0011-container-with-most-water) |
| [0015-3sum](https://github.com/DeadlyDragon131/LeetCode/tree/master/0015-3sum) |
| [0026-remove-duplicates-from-sorted-array](https://github.com/DeadlyDragon131/LeetCode/tree/master/0026-remove-duplicates-from-sorted-array) |
| [0041-first-missing-positive](https://github.com/DeadlyDragon131/LeetCode/tree/master/0041-first-missing-positive) |
| [0049-group-anagrams](https://github.com/DeadlyDragon131/LeetCode/tree/master/0049-group-anagrams) |
| [0066-plus-one](https://github.com/DeadlyDragon131/LeetCode/tree/master/0066-plus-one) |
| [0079-word-search](https://github.com/DeadlyDragon131/LeetCode/tree/master/0079-word-search) |
| [0088-merge-sorted-array](https://github.com/DeadlyDragon131/LeetCode/tree/master/0088-merge-sorted-array) |
| [0121-best-time-to-buy-and-sell-stock](https://github.com/DeadlyDragon131/LeetCode/tree/master/0121-best-time-to-buy-and-sell-stock) |
| [0122-best-time-to-buy-and-sell-stock-ii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0122-best-time-to-buy-and-sell-stock-ii) |
| [0136-single-number](https://github.com/DeadlyDragon131/LeetCode/tree/master/0136-single-number) |
| [0150-evaluate-reverse-polish-notation](https://github.com/DeadlyDragon131/LeetCode/tree/master/0150-evaluate-reverse-polish-notation) |
| [0167-two-sum-ii-input-array-is-sorted](https://github.com/DeadlyDragon131/LeetCode/tree/master/0167-two-sum-ii-input-array-is-sorted) |
| [0189-rotate-array](https://github.com/DeadlyDragon131/LeetCode/tree/master/0189-rotate-array) |
| [0200-number-of-islands](https://github.com/DeadlyDragon131/LeetCode/tree/master/0200-number-of-islands) |
| [0219-contains-duplicate-ii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0219-contains-duplicate-ii) |
| [0238-product-of-array-except-self](https://github.com/DeadlyDragon131/LeetCode/tree/master/0238-product-of-array-except-self) |
| [0260-single-number-iii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0260-single-number-iii) |
| [0283-move-zeroes](https://github.com/DeadlyDragon131/LeetCode/tree/master/0283-move-zeroes) |
| [0300-longest-increasing-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0300-longest-increasing-subsequence) |
| [0334-increasing-triplet-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0334-increasing-triplet-subsequence) |
| [0673-number-of-longest-increasing-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0673-number-of-longest-increasing-subsequence) |
| [0817-design-hashmap](https://github.com/DeadlyDragon131/LeetCode/tree/master/0817-design-hashmap) |
| [0873-guess-the-word](https://github.com/DeadlyDragon131/LeetCode/tree/master/0873-guess-the-word) |
| [1528-kids-with-the-greatest-number-of-candies](https://github.com/DeadlyDragon131/LeetCode/tree/master/1528-kids-with-the-greatest-number-of-candies) |
| [1635-number-of-good-pairs](https://github.com/DeadlyDragon131/LeetCode/tree/master/1635-number-of-good-pairs) |
| [2432-number-of-zero-filled-subarrays](https://github.com/DeadlyDragon131/LeetCode/tree/master/2432-number-of-zero-filled-subarrays) |
## Two Pointers
|  |
| ------- |
| [0011-container-with-most-water](https://github.com/DeadlyDragon131/LeetCode/tree/master/0011-container-with-most-water) |
| [0015-3sum](https://github.com/DeadlyDragon131/LeetCode/tree/master/0015-3sum) |
| [0026-remove-duplicates-from-sorted-array](https://github.com/DeadlyDragon131/LeetCode/tree/master/0026-remove-duplicates-from-sorted-array) |
| [0088-merge-sorted-array](https://github.com/DeadlyDragon131/LeetCode/tree/master/0088-merge-sorted-array) |
| [0125-valid-palindrome](https://github.com/DeadlyDragon131/LeetCode/tree/master/0125-valid-palindrome) |
| [0142-linked-list-cycle-ii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0142-linked-list-cycle-ii) |
| [0148-sort-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0148-sort-list) |
| [0151-reverse-words-in-a-string](https://github.com/DeadlyDragon131/LeetCode/tree/master/0151-reverse-words-in-a-string) |
| [0167-two-sum-ii-input-array-is-sorted](https://github.com/DeadlyDragon131/LeetCode/tree/master/0167-two-sum-ii-input-array-is-sorted) |
| [0189-rotate-array](https://github.com/DeadlyDragon131/LeetCode/tree/master/0189-rotate-array) |
| [0202-happy-number](https://github.com/DeadlyDragon131/LeetCode/tree/master/0202-happy-number) |
| [0234-palindrome-linked-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0234-palindrome-linked-list) |
| [0283-move-zeroes](https://github.com/DeadlyDragon131/LeetCode/tree/master/0283-move-zeroes) |
| [0392-is-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0392-is-subsequence) |
| [0908-middle-of-the-linked-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0908-middle-of-the-linked-list) |
| [1894-merge-strings-alternately](https://github.com/DeadlyDragon131/LeetCode/tree/master/1894-merge-strings-alternately) |
## String
|  |
| ------- |
| [0006-zigzag-conversion](https://github.com/DeadlyDragon131/LeetCode/tree/master/0006-zigzag-conversion) |
| [0014-longest-common-prefix](https://github.com/DeadlyDragon131/LeetCode/tree/master/0014-longest-common-prefix) |
| [0020-valid-parentheses](https://github.com/DeadlyDragon131/LeetCode/tree/master/0020-valid-parentheses) |
| [0049-group-anagrams](https://github.com/DeadlyDragon131/LeetCode/tree/master/0049-group-anagrams) |
| [0079-word-search](https://github.com/DeadlyDragon131/LeetCode/tree/master/0079-word-search) |
| [0125-valid-palindrome](https://github.com/DeadlyDragon131/LeetCode/tree/master/0125-valid-palindrome) |
| [0151-reverse-words-in-a-string](https://github.com/DeadlyDragon131/LeetCode/tree/master/0151-reverse-words-in-a-string) |
| [0205-isomorphic-strings](https://github.com/DeadlyDragon131/LeetCode/tree/master/0205-isomorphic-strings) |
| [0383-ransom-note](https://github.com/DeadlyDragon131/LeetCode/tree/master/0383-ransom-note) |
| [0392-is-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0392-is-subsequence) |
| [0535-encode-and-decode-tinyurl](https://github.com/DeadlyDragon131/LeetCode/tree/master/0535-encode-and-decode-tinyurl) |
| [0873-guess-the-word](https://github.com/DeadlyDragon131/LeetCode/tree/master/0873-guess-the-word) |
| [1146-greatest-common-divisor-of-strings](https://github.com/DeadlyDragon131/LeetCode/tree/master/1146-greatest-common-divisor-of-strings) |
| [1297-maximum-number-of-balloons](https://github.com/DeadlyDragon131/LeetCode/tree/master/1297-maximum-number-of-balloons) |
| [1894-merge-strings-alternately](https://github.com/DeadlyDragon131/LeetCode/tree/master/1894-merge-strings-alternately) |
## Dynamic Programming
|  |
| ------- |
| [0121-best-time-to-buy-and-sell-stock](https://github.com/DeadlyDragon131/LeetCode/tree/master/0121-best-time-to-buy-and-sell-stock) |
| [0122-best-time-to-buy-and-sell-stock-ii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0122-best-time-to-buy-and-sell-stock-ii) |
| [0300-longest-increasing-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0300-longest-increasing-subsequence) |
| [0338-counting-bits](https://github.com/DeadlyDragon131/LeetCode/tree/master/0338-counting-bits) |
| [0392-is-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0392-is-subsequence) |
| [0673-number-of-longest-increasing-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0673-number-of-longest-increasing-subsequence) |
## Trie
|  |
| ------- |
| [0014-longest-common-prefix](https://github.com/DeadlyDragon131/LeetCode/tree/master/0014-longest-common-prefix) |
## Bit Manipulation
|  |
| ------- |
| [0136-single-number](https://github.com/DeadlyDragon131/LeetCode/tree/master/0136-single-number) |
| [0190-reverse-bits](https://github.com/DeadlyDragon131/LeetCode/tree/master/0190-reverse-bits) |
| [0191-number-of-1-bits](https://github.com/DeadlyDragon131/LeetCode/tree/master/0191-number-of-1-bits) |
| [0201-bitwise-and-of-numbers-range](https://github.com/DeadlyDragon131/LeetCode/tree/master/0201-bitwise-and-of-numbers-range) |
| [0260-single-number-iii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0260-single-number-iii) |
| [0338-counting-bits](https://github.com/DeadlyDragon131/LeetCode/tree/master/0338-counting-bits) |
| [0371-sum-of-two-integers](https://github.com/DeadlyDragon131/LeetCode/tree/master/0371-sum-of-two-integers) |
## Divide and Conquer
|  |
| ------- |
| [0148-sort-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0148-sort-list) |
| [0190-reverse-bits](https://github.com/DeadlyDragon131/LeetCode/tree/master/0190-reverse-bits) |
| [0191-number-of-1-bits](https://github.com/DeadlyDragon131/LeetCode/tree/master/0191-number-of-1-bits) |
## Math
|  |
| ------- |
| [0066-plus-one](https://github.com/DeadlyDragon131/LeetCode/tree/master/0066-plus-one) |
| [0150-evaluate-reverse-polish-notation](https://github.com/DeadlyDragon131/LeetCode/tree/master/0150-evaluate-reverse-polish-notation) |
| [0189-rotate-array](https://github.com/DeadlyDragon131/LeetCode/tree/master/0189-rotate-array) |
| [0202-happy-number](https://github.com/DeadlyDragon131/LeetCode/tree/master/0202-happy-number) |
| [0371-sum-of-two-integers](https://github.com/DeadlyDragon131/LeetCode/tree/master/0371-sum-of-two-integers) |
| [0873-guess-the-word](https://github.com/DeadlyDragon131/LeetCode/tree/master/0873-guess-the-word) |
| [1146-greatest-common-divisor-of-strings](https://github.com/DeadlyDragon131/LeetCode/tree/master/1146-greatest-common-divisor-of-strings) |
| [1635-number-of-good-pairs](https://github.com/DeadlyDragon131/LeetCode/tree/master/1635-number-of-good-pairs) |
| [2432-number-of-zero-filled-subarrays](https://github.com/DeadlyDragon131/LeetCode/tree/master/2432-number-of-zero-filled-subarrays) |
## Interactive
|  |
| ------- |
| [0873-guess-the-word](https://github.com/DeadlyDragon131/LeetCode/tree/master/0873-guess-the-word) |
## Game Theory
|  |
| ------- |
| [0873-guess-the-word](https://github.com/DeadlyDragon131/LeetCode/tree/master/0873-guess-the-word) |
## Prefix Sum
|  |
| ------- |
| [0238-product-of-array-except-self](https://github.com/DeadlyDragon131/LeetCode/tree/master/0238-product-of-array-except-self) |
## Greedy
|  |
| ------- |
| [0011-container-with-most-water](https://github.com/DeadlyDragon131/LeetCode/tree/master/0011-container-with-most-water) |
| [0122-best-time-to-buy-and-sell-stock-ii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0122-best-time-to-buy-and-sell-stock-ii) |
| [0334-increasing-triplet-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0334-increasing-triplet-subsequence) |
## Binary Search
|  |
| ------- |
| [0167-two-sum-ii-input-array-is-sorted](https://github.com/DeadlyDragon131/LeetCode/tree/master/0167-two-sum-ii-input-array-is-sorted) |
| [0300-longest-increasing-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0300-longest-increasing-subsequence) |
## Hash Table
|  |
| ------- |
| [0041-first-missing-positive](https://github.com/DeadlyDragon131/LeetCode/tree/master/0041-first-missing-positive) |
| [0049-group-anagrams](https://github.com/DeadlyDragon131/LeetCode/tree/master/0049-group-anagrams) |
| [0142-linked-list-cycle-ii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0142-linked-list-cycle-ii) |
| [0202-happy-number](https://github.com/DeadlyDragon131/LeetCode/tree/master/0202-happy-number) |
| [0205-isomorphic-strings](https://github.com/DeadlyDragon131/LeetCode/tree/master/0205-isomorphic-strings) |
| [0219-contains-duplicate-ii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0219-contains-duplicate-ii) |
| [0383-ransom-note](https://github.com/DeadlyDragon131/LeetCode/tree/master/0383-ransom-note) |
| [0535-encode-and-decode-tinyurl](https://github.com/DeadlyDragon131/LeetCode/tree/master/0535-encode-and-decode-tinyurl) |
| [0817-design-hashmap](https://github.com/DeadlyDragon131/LeetCode/tree/master/0817-design-hashmap) |
| [1297-maximum-number-of-balloons](https://github.com/DeadlyDragon131/LeetCode/tree/master/1297-maximum-number-of-balloons) |
| [1635-number-of-good-pairs](https://github.com/DeadlyDragon131/LeetCode/tree/master/1635-number-of-good-pairs) |
## Binary Indexed Tree
|  |
| ------- |
| [0673-number-of-longest-increasing-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0673-number-of-longest-increasing-subsequence) |
## Segment Tree
|  |
| ------- |
| [0673-number-of-longest-increasing-subsequence](https://github.com/DeadlyDragon131/LeetCode/tree/master/0673-number-of-longest-increasing-subsequence) |
## Stack
|  |
| ------- |
| [0020-valid-parentheses](https://github.com/DeadlyDragon131/LeetCode/tree/master/0020-valid-parentheses) |
| [0150-evaluate-reverse-polish-notation](https://github.com/DeadlyDragon131/LeetCode/tree/master/0150-evaluate-reverse-polish-notation) |
| [0155-min-stack](https://github.com/DeadlyDragon131/LeetCode/tree/master/0155-min-stack) |
| [0234-palindrome-linked-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0234-palindrome-linked-list) |
## Design
|  |
| ------- |
| [0155-min-stack](https://github.com/DeadlyDragon131/LeetCode/tree/master/0155-min-stack) |
| [0535-encode-and-decode-tinyurl](https://github.com/DeadlyDragon131/LeetCode/tree/master/0535-encode-and-decode-tinyurl) |
| [0817-design-hashmap](https://github.com/DeadlyDragon131/LeetCode/tree/master/0817-design-hashmap) |
## Backtracking
|  |
| ------- |
| [0079-word-search](https://github.com/DeadlyDragon131/LeetCode/tree/master/0079-word-search) |
## Depth-First Search
|  |
| ------- |
| [0079-word-search](https://github.com/DeadlyDragon131/LeetCode/tree/master/0079-word-search) |
| [0200-number-of-islands](https://github.com/DeadlyDragon131/LeetCode/tree/master/0200-number-of-islands) |
## Matrix
|  |
| ------- |
| [0079-word-search](https://github.com/DeadlyDragon131/LeetCode/tree/master/0079-word-search) |
| [0200-number-of-islands](https://github.com/DeadlyDragon131/LeetCode/tree/master/0200-number-of-islands) |
## Breadth-First Search
|  |
| ------- |
| [0200-number-of-islands](https://github.com/DeadlyDragon131/LeetCode/tree/master/0200-number-of-islands) |
## Union Find
|  |
| ------- |
| [0200-number-of-islands](https://github.com/DeadlyDragon131/LeetCode/tree/master/0200-number-of-islands) |
## Sorting
|  |
| ------- |
| [0015-3sum](https://github.com/DeadlyDragon131/LeetCode/tree/master/0015-3sum) |
| [0049-group-anagrams](https://github.com/DeadlyDragon131/LeetCode/tree/master/0049-group-anagrams) |
| [0088-merge-sorted-array](https://github.com/DeadlyDragon131/LeetCode/tree/master/0088-merge-sorted-array) |
| [0148-sort-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0148-sort-list) |
## Linked List
|  |
| ------- |
| [0025-reverse-nodes-in-k-group](https://github.com/DeadlyDragon131/LeetCode/tree/master/0025-reverse-nodes-in-k-group) |
| [0092-reverse-linked-list-ii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0092-reverse-linked-list-ii) |
| [0142-linked-list-cycle-ii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0142-linked-list-cycle-ii) |
| [0148-sort-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0148-sort-list) |
| [0206-reverse-linked-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0206-reverse-linked-list) |
| [0234-palindrome-linked-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0234-palindrome-linked-list) |
| [0817-design-hashmap](https://github.com/DeadlyDragon131/LeetCode/tree/master/0817-design-hashmap) |
| [0908-middle-of-the-linked-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0908-middle-of-the-linked-list) |
## Merge Sort
|  |
| ------- |
| [0148-sort-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0148-sort-list) |
## Hash Function
|  |
| ------- |
| [0535-encode-and-decode-tinyurl](https://github.com/DeadlyDragon131/LeetCode/tree/master/0535-encode-and-decode-tinyurl) |
| [0817-design-hashmap](https://github.com/DeadlyDragon131/LeetCode/tree/master/0817-design-hashmap) |
## Counting
|  |
| ------- |
| [0383-ransom-note](https://github.com/DeadlyDragon131/LeetCode/tree/master/0383-ransom-note) |
| [1297-maximum-number-of-balloons](https://github.com/DeadlyDragon131/LeetCode/tree/master/1297-maximum-number-of-balloons) |
| [1635-number-of-good-pairs](https://github.com/DeadlyDragon131/LeetCode/tree/master/1635-number-of-good-pairs) |
## Sliding Window
|  |
| ------- |
| [0219-contains-duplicate-ii](https://github.com/DeadlyDragon131/LeetCode/tree/master/0219-contains-duplicate-ii) |
## Recursion
|  |
| ------- |
| [0025-reverse-nodes-in-k-group](https://github.com/DeadlyDragon131/LeetCode/tree/master/0025-reverse-nodes-in-k-group) |
| [0206-reverse-linked-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0206-reverse-linked-list) |
| [0234-palindrome-linked-list](https://github.com/DeadlyDragon131/LeetCode/tree/master/0234-palindrome-linked-list) |
<!---LeetCode Topics End-->