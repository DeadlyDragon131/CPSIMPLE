class Solution {
public:
    bool isValid(string s) {
        stack<char> st;
        unordered_map <char,char> m = {{'}','{'},{')','('},{']','['}};
        for (int i = 0;i < s.size(); i++){
            if(m.find(s[i]) != m.end()){
                if(st.empty()){
                    return false;
                }
                if(m[s[i]] == st.top()){
                    st.pop();
                }
                else{
                    return false;
                }
            }
            else{
                st.push(s[i]);
            }
        }
        if(st.empty()){
            return true;
        }
        return false;
    }
};