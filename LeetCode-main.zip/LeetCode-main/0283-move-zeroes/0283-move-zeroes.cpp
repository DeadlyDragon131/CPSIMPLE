class Solution {
public:
    void moveZeroes(vector<int>& nums) {
         int cnt = 0;
         int n = nums.size();
         for(auto x:nums){
            if(x == 0){
                cnt++;
            }
         }
         int k = 0;
         for(int j = 0;j < n;j++){
            if(nums[j] != 0){
                nums[k] = nums[j];
                k++;
            }
         }
         for(int i = 0;i < cnt;i++){
            nums[k] = 0;
            k++;
         }
    }
};