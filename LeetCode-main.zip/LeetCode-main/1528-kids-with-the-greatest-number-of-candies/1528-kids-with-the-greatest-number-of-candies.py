class Solution:
    def kidsWithCandies(self, candies: List[int], extraCandies: int) -> List[bool]:
        maxcandies = max(candies)
        return [(curcandies + extraCandies >= maxcandies) for curcandies in candies]