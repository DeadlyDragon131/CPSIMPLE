class Solution {
public:
    vector<int> singleNumber(vector<int>& nums) {
        int res = nums[0];
        for(int i = 1;i < nums.size(); i++){
            res ^= nums[i];
        } 
        vector<int> myarr(2);
        int j = 0;
        while(!((res >> j)&1)){
            j++;
        }
        int a = 0,b = 0;
        for(int k = 0;k < nums.size(); k++){
            if((nums[k] >> j) & 1){
                a ^= nums[k];
            }
            else{
                b ^= nums[k];
            }
        }
        myarr[0] = (a);
        myarr[1] = (b);
        return myarr;
    }
};