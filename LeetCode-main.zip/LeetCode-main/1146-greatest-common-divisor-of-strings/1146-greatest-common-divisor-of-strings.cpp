class Solution {
public:
    string gcdOfStrings(string str1, string str2) {
        int n1 = str1.size();
        int n2 = str2.size();

        // Function to check if length 'l' can be a common divisor pattern
        auto isDivisor = [&](int l) -> bool {
            if (n1 % l != 0 || n2 % l != 0) {
                return false; // Must divide both lengths
            }
            string base = str1.substr(0, l); // The potential repeating substring
            
            // Construct full strings by repeating `base`
            string repeated1 = "", repeated2 = "";
            for (int i = 0; i < n1 / l; i++) repeated1 += base;
            for (int i = 0; i < n2 / l; i++) repeated2 += base;

            return (repeated1 == str1 && repeated2 == str2);
        };

        // Try all divisors from min(n1, n2) to 1
        for (int i = min(n1, n2); i >= 1; i--) {
            if (isDivisor(i)) {
                return str1.substr(0, i); // The GCD string
            }
        }

        return ""; // No common divisor string found
    }
};
