class Solution {
public:
    bool increasingTriplet(vector<int>& nums) {
        long long first = LONG_MAX;
        long long second = LONG_MAX;
        for(int  i= 0;i < nums.size();i++){
            if(first >= nums[i]){
                first = nums[i];
            }
            else if(second >= nums[i]){
                second = nums[i];
            }
            else{
                return true;
            }
        }
        return false;
    }
};