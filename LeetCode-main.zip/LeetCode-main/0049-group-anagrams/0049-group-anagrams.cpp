class Solution
{
    public:
        vector<vector < string>> groupAnagrams(vector<string> &strs)
        {

            map<vector < int>, vector< string>> um;
            vector<int> arr(26);

            for (auto &x: strs)
            {
                for (int i = 0; i < 26; i++)
                {
                    arr[i] = 0;
                }
                for (int i = 0; i < x.size(); i++)
                {
                    arr[x[i] - 'a'] += 1;
                }
                um[arr].push_back(x);
            }
            vector<vector < string>> result;
            for (auto &entry: um)
            {
                result.push_back(entry.second);
            }

            return result;
        }
};