class Solution {
public:
    vector<int> countBits(int n) {
        vector<int> myarr(n+1,0);
        for(int i = 0;i <= n;i++){
            int j = i;
            while(j){
                j &= j-1;
                myarr[i] += 1;
            }
        }
        return myarr;
    }
};